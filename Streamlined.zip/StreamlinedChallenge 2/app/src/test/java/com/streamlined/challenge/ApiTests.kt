package com.streamlined.challenge

import BaseTest
import com.streamlined.challenge.data.AppApi
import com.streamlined.challenge.data.model.GetBreedsRequest
import com.streamlined.challenge.data.model.toMap
import kotlinx.coroutines.runBlocking
import org.junit.Assert
import org.junit.Before
import org.junit.Test
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class ApiTests : BaseTest() {

    private lateinit var api: AppApi

    @Before
    fun setup() {
        val url = mockWebServer.url("/")
        api = Retrofit.Builder()
            .baseUrl(url)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(AppApi::class.java)
    }


    private fun <T> checkApiResponse(breadsModel: Response<T>){
        Assert.assertTrue(breadsModel.isSuccessful)
        Assert.assertNotNull(breadsModel)
        Assert.assertNotNull(breadsModel.body())
    }

    @Test
    fun api_breeds_test() {
        enqueue("breeds.json")
        runBlocking {
            val breadsModel = api.getBreeds(GetBreedsRequest().toMap())
            checkApiResponse(breadsModel)

            Assert.assertTrue("The list was empty", breadsModel.body()?.data!!.isNotEmpty())
            Assert.assertEquals("The id's did not match", "Abyssinian", breadsModel.body()!!.data[0].breed)
        }
    }

}