package com.streamlined.challenge

import BaseTest
import com.streamlined.challenge.data.AppApi
import com.streamlined.challenge.data.AppRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert
import org.junit.Before
import org.junit.Test
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class AppViewModelTests : BaseTest() {

    private lateinit var service: AppApi
    private lateinit var viewModel:AppViewModel

    @Before
    fun setup() {
        val url = mockWebServer.url("/")
        service = Retrofit.Builder()
            .baseUrl(url)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(AppApi::class.java)

        val repository = AppRepository(service)
        viewModel = AppViewModel(repository)
    }

    @Test
    fun canLoadMore_test() {
        runBlocking {
            val canLoad = viewModel.canLoadMore(-1)
            Assert.assertEquals("The average response did not match", true  , canLoad)
        }
    }


    @Test
    fun getTime_test() {
        runBlocking {
            val averageResponse = viewModel.getTime(1655635324489)
            Assert.assertEquals("The average response did not match", "10:42:04.489", averageResponse)
        }
    }

}