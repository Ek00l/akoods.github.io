package com.streamlined.challenge.common


// to show progress circle while waiting for requests data and hide it after that using the ProgressDialog.kt class
sealed class ChannelActions {
    object ShowProgress : ChannelActions()
    object HideProgress : ChannelActions()
}
