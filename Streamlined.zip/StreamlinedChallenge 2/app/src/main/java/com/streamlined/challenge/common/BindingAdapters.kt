package com.streamlined.challenge.common

import androidx.databinding.BindingAdapter
import androidx.recyclerview.widget.RecyclerView
import com.streamlined.challenge.data.model.DetailModel
import com.streamlined.challenge.ui.CatFactsAdapter


@BindingAdapter("listItems")
fun bindRecyclerView(recyclerView: RecyclerView, data: List<DetailModel>?) {
    (recyclerView.adapter as CatFactsAdapter).submitList(data?.toList())
}