package com.streamlined.challenge.data.config

import okhttp3.Interceptor
import okhttp3.Response

class AppInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
            .newBuilder()
            .addHeader("Content-Type", "application/json")
            .addHeader("X-Platform", "Android")
            .method(chain.request().method, chain.request().body)
            .build()
        return chain.proceed(request)
    }
}