package com.streamlined.challenge.data.model

import java.io.Serializable

data class DetailModel(
    val breed: String?,
    val country: String?,
    val origin: String?,
    val coat: String?,
    val pattern: String?
) : Serializable {
    constructor() : this("street", "anywhere", "egypt", "mangy", "camo")
}
