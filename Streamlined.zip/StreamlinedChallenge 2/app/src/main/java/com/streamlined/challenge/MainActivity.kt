package com.streamlined.challenge

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.flowWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import com.google.android.material.snackbar.Snackbar
import com.streamlined.challenge.common.ChannelActions
import com.streamlined.challenge.common.ProgressDialog
import com.streamlined.challenge.data.model.CatFactModel
import com.streamlined.challenge.databinding.ActivityMainBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {
    private val viewModel : AppViewModel by viewModels()

    val progress: ProgressDialog? by lazy { ProgressDialog(this) }

    private lateinit var binding: ActivityMainBinding
    private lateinit var appBarConfiguration: AppBarConfiguration

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)


        val navController = findNavController(R.id.nav_host_fragment)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        appBarConfiguration = AppBarConfiguration(setOf(R.id.breedsFragment))
        setupActionBarWithNavController(navController, appBarConfiguration)

        binding.randomCatFact.setOnClickListener { view ->
            viewModel.getCatFact()
            viewModel.catFact.observe(this) { catFact ->
                showFact(view, catFact)
            }
        }

        handleChannelEvent(viewModel.actionFlow)
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }

    private fun showFact(view: View, catFact: CatFactModel) {
        Snackbar.make(view,
            getString(R.string.random_cat_fact_label) + catFact.fact,
            Snackbar.LENGTH_LONG)
            .setAction("Action", null).show()
    }

    fun handleChannelEvent(flow: Flow<ChannelActions>){
        flow
            .onEach {
                when (it) {
                    ChannelActions.ShowProgress ->
                        progress?.show()
                    ChannelActions.HideProgress ->
                        progress?.dismiss()
                }
            }
            .flowWithLifecycle(lifecycle)
            .launchIn(lifecycleScope)
    }
}