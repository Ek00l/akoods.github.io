package com.streamlined.challenge.common

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import android.widget.Toast
import com.streamlined.challenge.R

private const val TAG = "Utility"

object Utility {

    // this method check the internet connection:
// result is 2 for WiFi, 1 for Mobile data, 3 for VPN or 0 for unavailable
    fun isInternetAvailable(): Boolean {
        var result = 0 // Returns connection type. 0: none; 1: mobile data; 2: wifi
        val connectivityManager =
            App.context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager?
        connectivityManager?.run {
            connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)?.run {
                when {
                    hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                        result = 2
                    }
                    hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                        result = 1
                    }
                    hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> {
                        result = 3
                    }
                }
            }
        }
        if (result == 0) {
            Toast.makeText(App.context,
                R.string.please_check_your_connection_and_try_again, Toast.LENGTH_SHORT).show()
        }
        Log.i(TAG, "isInternetAvailable: $result")
        return result != 0
    }
}