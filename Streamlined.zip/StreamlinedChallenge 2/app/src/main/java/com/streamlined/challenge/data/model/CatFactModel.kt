package com.streamlined.challenge.data.model

// TODO
data class CatFactModel(
    val fact: String?,
    val length: Int
)