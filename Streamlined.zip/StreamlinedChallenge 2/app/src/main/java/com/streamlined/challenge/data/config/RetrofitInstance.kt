package com.streamlined.challenge.data.config

import com.streamlined.challenge.BuildConfig
import com.streamlined.challenge.data.AppApi
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.security.GeneralSecurityException
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.*


object RetrofitInstance {

    private fun configureClient(client: OkHttpClient.Builder): OkHttpClient.Builder {
        try {
            // Create a trust manager that does not validate certificate chains
            val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> {
                    return arrayOf()
                }
            })

            // Install the all-trusting trust manager
            val sslContext = SSLContext.getInstance("SSL")
            sslContext.init(null, trustAllCerts, SecureRandom())

            // Create an ssl socket factory with our all-trusting manager
            val sslSocketFactory = sslContext.socketFactory

            client.sslSocketFactory(sslSocketFactory, (trustAllCerts[0] as X509TrustManager))
            client.hostnameVerifier { _: String?, _: SSLSession? -> true }
        } catch (e: GeneralSecurityException) {
            e.printStackTrace()
        }
        return client
    }

    // to give us feedback throw logcat view
    private var logging = HttpLoggingInterceptor().apply {
        if (BuildConfig.DEBUG)
            setLevel(HttpLoggingInterceptor.Level.BODY)
        else setLevel(HttpLoggingInterceptor.Level.NONE)
    }

    // creating hte client to deal with APIs
    private val client = configureClient(OkHttpClient.Builder()).apply {
        retryOnConnectionFailure(true)

        writeTimeout(5, TimeUnit.MINUTES)
        connectTimeout(2, TimeUnit.MINUTES)
        readTimeout(2, TimeUnit.MINUTES)

        addInterceptor(logging)
        addInterceptor(AppInterceptor())
    }.build()


    // to return a retrofit object that help us making requests using AppApi.kt interface
    fun retrofit(url:String) : Retrofit {
        return Retrofit.Builder()
            .baseUrl(url)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }
}