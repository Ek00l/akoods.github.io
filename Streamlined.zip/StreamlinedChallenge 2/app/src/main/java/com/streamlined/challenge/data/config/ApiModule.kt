package com.streamlined.challenge.data.config

import com.streamlined.challenge.BuildConfig
import com.streamlined.challenge.data.AppApi
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object ApiModule {

    @Singleton
    @Provides
    fun provideAppApi(): AppApi {
        val url = BuildConfig.BASE_URL
        return RetrofitInstance.retrofit(url).create(AppApi::class.java)
    }

    @Singleton
    @Provides
    fun provideCoroutineDispatcher(): CoroutineDispatcher {
        return Dispatchers.IO
    }
}