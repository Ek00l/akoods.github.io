package com.streamlined.challenge.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.streamlined.challenge.data.model.DetailModel
import com.streamlined.challenge.databinding.ItemCatFactBinding

class CatFactsAdapter(private val listener: (DetailModel) -> Unit) :
    ListAdapter<DetailModel, CatFactsAdapter.BreedViewHolder>(DiffCallback) {

    companion object DiffCallback : DiffUtil.ItemCallback<DetailModel>() {
        override fun areItemsTheSame(oldItem: DetailModel, newItem: DetailModel): Boolean {
            return oldItem.breed == newItem.breed
        }

        override fun areContentsTheSame(oldItem: DetailModel, newItem: DetailModel): Boolean {
            return oldItem.breed == newItem.breed
                    && oldItem.country == newItem.country
                    && oldItem.origin == newItem.origin
                    && oldItem.coat == newItem.coat
                    && oldItem.pattern == newItem.pattern
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BreedViewHolder {
        // create a breed list item
        return BreedViewHolder(ItemCatFactBinding.inflate(
            LayoutInflater.from(parent.context), parent, false))
    }

    /**
     * Replace the contents of a view (invoked by the layout manager)
     */
    override fun onBindViewHolder(holder: BreedViewHolder, position: Int) {
        holder.bind(getItem(position))
    }


    inner class BreedViewHolder(private val binding: ItemCatFactBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(breed: DetailModel) {
            binding.breed = breed
            binding.executePendingBindings()

            itemView.setOnClickListener { listener(breed) }
        }
    }
}

