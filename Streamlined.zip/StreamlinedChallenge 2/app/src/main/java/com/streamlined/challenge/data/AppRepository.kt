package com.streamlined.challenge.data

import com.streamlined.challenge.data.model.BreedsModel
import com.streamlined.challenge.data.model.CatFactModel
import com.streamlined.challenge.data.model.GetBreedsRequest
import com.streamlined.challenge.data.model.toMap
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response
import javax.inject.Inject

open class AppRepository @Inject constructor(
    private val api: AppApi,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
)  {

    suspend fun getBreeds(params: GetBreedsRequest): Response<BreedsModel> {
        return withContext(ioDispatcher) {
            api.getBreeds(params.toMap())
        }
    }

    suspend fun getCatFact(): Response<CatFactModel> {
        return withContext(ioDispatcher) {
            api.getCatFact()
        }
    }
}