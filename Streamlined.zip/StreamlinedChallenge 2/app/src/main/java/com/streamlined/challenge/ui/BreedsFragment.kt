package com.streamlined.challenge.ui

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.streamlined.challenge.AppViewModel
import com.streamlined.challenge.MainActivity
import com.streamlined.challenge.R
import com.streamlined.challenge.databinding.FragmentBreedsBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class BreedsFragment : Fragment() {
    private val viewModel:AppViewModel by activityViewModels()

    private var _binding: FragmentBreedsBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: CatFactsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentBreedsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.apply {
            viewModel = this@BreedsFragment.viewModel
            lifecycleOwner = this@BreedsFragment

            adapter = CatFactsAdapter { model ->
                findNavController().navigate(
                    BreedsFragmentDirections.navigateToBreedDetailsFragment(model)
                )
            }

            recyclerView.adapter = adapter
            recyclerView.setHasFixedSize(true)

            val layoutManager = recyclerView.layoutManager as LinearLayoutManager
            recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    super.onScrolled(recyclerView, dx, dy)
                    val lastVisiblePosition: Int = layoutManager.findLastVisibleItemPosition()
                    if (this@BreedsFragment.viewModel.canLoadMore(lastVisiblePosition)) {
                        this@BreedsFragment.viewModel.loadBreeds()
                    }
                }
            })
        }
        activity?.actionBar?.setTitle(R.string.breeds)
        (requireActivity() as MainActivity).handleChannelEvent(viewModel.actionFlow)

        viewModel.loadBreeds()
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        // Inflate the menu; this adds items to the action bar if it is present.
        inflater.inflate(R.menu.menu_main, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_metrics -> {
                findNavController().navigate(R.id.navigateToMetricsFragment)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
