package com.streamlined.challenge

import android.os.Build
import android.os.Build.VERSION_CODES
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.streamlined.challenge.common.ChannelActions
import com.streamlined.challenge.common.SingleLiveEvent
import com.streamlined.challenge.common.Utility
import com.streamlined.challenge.data.AppRepository
import com.streamlined.challenge.data.model.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import javax.inject.Inject


private const val TAG = "AppViewModel"

@HiltViewModel
class AppViewModel
@Inject constructor(private val repository: AppRepository) : ViewModel() {

    private val actionChannel =
        Channel<ChannelActions>(capacity = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val actionFlow = actionChannel.receiveAsFlow()

    var breedsParams: GetBreedsRequest = GetBreedsRequest()

    private var breedsModel: BreedsModel? = null
    private val _breeds = SingleLiveEvent<MutableList<DetailModel>>()
    val breeds: LiveData<MutableList<DetailModel>> = _breeds

    private val _catFact = SingleLiveEvent<CatFactModel>()
    val catFact: LiveData<CatFactModel> = _catFact

    var metricsModel: MetricsModel? = null

    // check if internet is available
    private fun isNetworkConnected(): Boolean {
        return Utility.isInternetAvailable()
    }

    // show progress dialog
    private fun viewProgress() {
        actionChannel.trySend(ChannelActions.ShowProgress)
    }

    // hide progress dialog
    private fun hideProgress() {
        actionChannel.trySend(ChannelActions.HideProgress)
    }

    // handle exceptions from retrofit
    private val exceptionHandler = CoroutineExceptionHandler { _, throwable ->
        hideProgress()
        Log.e(TAG, "Exception handled: ${throwable.localizedMessage}")
        if (BuildConfig.STAGING) throwable.printStackTrace()
    }


    fun loadBreeds() {
        if(breedsParams.page <= (breedsModel?.last_page ?: 1)) {
            breedsParams.page = breedsModel?.current_page?.plus(1) ?: 1
            getBreeds(breedsParams)
        }
    }

    fun canLoadMore(lastVisiblePosition: Int): Boolean {
        return lastVisiblePosition == (_breeds.value?.size ?: 0) - 1
    }

    private fun getBreeds(params: GetBreedsRequest) {
        if (isNetworkConnected()) {
            viewModelScope.launch(exceptionHandler) {
                viewProgress()
                repository.getBreeds(params).let {
                    if (it.isSuccessful) {
                        breedsModel = it.body()
                        (it.body()?.data ?: mutableListOf()).let {
                            val breads = _breeds.value ?: mutableListOf()
                            breads.addAll(it)
                            _breeds.value =  breads
                        }
                        setMetrics(it.raw())
                    }
                }
                hideProgress()
            }
        }
    }

    fun getCatFact() {
        if (isNetworkConnected()) {
            viewModelScope.launch(exceptionHandler) {
                viewProgress()
                repository.getCatFact().let {
                    if (it.isSuccessful)
                        _catFact.value = it.body()
                    setMetrics(it.raw())
                }
                hideProgress()
            }
        }
    }

    private fun setMetrics(raw: okhttp3.Response) {
        val osName = VERSION_CODES::class.java.fields[Build.VERSION.SDK_INT].name
        val deviceName = android.os.Build.MODEL
        val sentRequestTime = getTime(raw.sentRequestAtMillis)
        val receivedResponseTime = getTime(raw.receivedResponseAtMillis)
        val averageResponse = getTime(raw.receivedResponseAtMillis - raw.sentRequestAtMillis)
        metricsModel = MetricsModel(
            osName,deviceName,sentRequestTime,receivedResponseTime,averageResponse
        )
    }


    fun getTime(millis:Long) : String{
        return DateTimeFormatter.ofPattern("HH:mm:ss.SSS")
            .withZone(ZoneId.of("UTC"))
            .format(Instant.ofEpochMilli(millis));
    }
}
