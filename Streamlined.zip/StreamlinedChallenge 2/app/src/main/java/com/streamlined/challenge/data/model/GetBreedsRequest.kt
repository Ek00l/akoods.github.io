package com.streamlined.challenge.data.model

import com.google.gson.annotations.SerializedName

data class GetBreedsRequest(
    @SerializedName("page") var page: Int = 1,  // page number
    @SerializedName("limit") var limit: Int = 30,  // limit the amount of results returned
)

fun GetBreedsRequest.toMap(): HashMap<String, String> {
    val map: HashMap<String, String> = HashMap()
    map["page"] = page.toString()
    map["limit"] = limit.toString()
    return map
}
