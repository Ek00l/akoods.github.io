package com.streamlined.challenge.data

import com.streamlined.challenge.data.model.BreedsModel
import com.streamlined.challenge.data.model.CatFactModel
import retrofit2.Response
import retrofit2.http.*

// this Interface is to handle api requests.
interface AppApi {

    // this is a request to get Breeds
    @GET("breeds")
    suspend fun getBreeds(@QueryMap params: Map<String, String>): Response<BreedsModel>

    // this is a request to get facts about cats
    @GET("fact")
    suspend fun getCatFact(): Response<CatFactModel>
}