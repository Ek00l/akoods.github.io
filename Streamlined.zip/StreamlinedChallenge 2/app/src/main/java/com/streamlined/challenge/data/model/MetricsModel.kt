package com.streamlined.challenge.data.model

import java.io.Serializable

data class MetricsModel(
    val deviceName: String?,
    val osName: String?,
    val sentRequestTime: String?,
    val receivedResponseTime: String?,
    val averageResponse:String?

    ) : Serializable {
    constructor() : this("newton", "pda", "00:00:00", "00:00:00","00:00:00")
}
