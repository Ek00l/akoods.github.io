I edit many things to app like:

Added 3 libraries

Removed the metrics button from the metrics page because clicking again was crashing the app.

scrolling to the bottom of the page and click any row and click the back button it will refresh more rows.

Added back button to the detail page to help the user use the app smoothly.

Added unit test for the app

Increase the speed for app

Removed some bugs

Made it look ready for production.

Everything up to date in this code.

Used the java 11 update in project structure to make sure everything is good.

  

